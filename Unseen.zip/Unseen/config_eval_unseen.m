% general configurations

% feature tpye
feat_line = 'AmsRastaplpMfccGf';

% unseen noise type
noise_line = 'pink_destroyerengine'; % unseen noise type

% number of times that each clean utterance is mixed with noise for training.
repeat_time = 1; 

test_list = ['config' filesep 'list50.txt'];

% cut noise into two parts, the first part is for training and the second part is for test
noise_cut = 0.5;

% create mixtures at certain SNR
mix_db = [-3, 0, 3, 6]; 

% use ideal ratio mask or ideal binary mask as learning target
is_ratio_mask = 1;

% 1. generate mixtures or not. 0: no, 1: yes.
is_gen_mix = 0;

% 2. generate features/masks or not. 0: no, 1: yes.
is_gen_feat = 0;

% 3. perform dnn test or not. 0: no, 1: yes.
is_dnn = 1;

model_path = 'E:\TEST_KALMAN\UNSEEN\model_babble_white_street_factory_db-3   0   3  6.mat';  % trained model_path 

TRAIN_STORE = 'E:\TEST_KALMAN\UNSEEN\train_babble_white_street_factory_Joint.mat'; % Training speech features store_path (used for normalization)
