function features= get_training_data( mix_sig, fun_name )
%Returns training features and labels
% Input:
% mix_sig: noisy speech
% voice_sig: clean speech
% fun_name: function name for obtaining the feature
% fs: sampling frequency
% win_len: window length
% win_shift: shift between windows

%num_harm = 12;
%sca_fac = 10;

isTrun = 0;

% Obtain features for training & testing
f1 = feval(fun_name, mix_sig);


% use STFT features instead
%win_fun = hanning(win_len);
%mix_frame = enframe(mix_sig, win_fun, win_shift);
%tmp_features = fft(mix_frame');
%tmp_features = abs(tmp_features);


%features(:,:) = f1(:,1:num_frame);
%features(:,:) = tmp_features((1:floor(win_len/2)+1),1:num_frame);

features = single(f1);


end

