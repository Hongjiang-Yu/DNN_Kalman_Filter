function [ syn_wav ] = wav_synthesis( label, mix, fs, win_len, win_shift, sca_fac, isIdeal, IRM_gamma, IRM_eps)
%Returns a synthesised speech using the output from NN
% Input:
% label: output from DNN, matrix containing amplititude and IF (phase)
% fs: sampling frequency
% win_len: window length
% win_shift: shift between windows
% sca_fac: scaling factor used in generating the training labels

win_fun = hanning(win_len);

%normalize mix
mix = mix./max(mix);

% use mix angel for generating the waveform
mix_frame = enframe(mix, win_fun, win_shift);

mix_fft = fft(mix_frame')';
mix_phase = angle(mix_fft);

label = label';
%num_col_split = size(label,2)/2;
num_col_split = size(label,2);

% use for ad_bpd
%num_col_split = floor(win_len/2);

num_frame = size(label, 1);
%amp_frame = zeros(num_frame, win_len);
%phase_frame = zeros(num_frame, win_len);

% split the labels into ampltitude matrix and phase matrix
% MODIFIED: use IF instead of phase
amp_frame = label(:, 1:num_col_split);

% throw the values below the threshold
thres = 0 / sca_fac;
idx = amp_frame<thres;
amp_frame(idx) = 0;

% postprocessing by IRM
row_mix = size(mix_fft,1);
row_out = size(amp_frame,1);
row_min = min(row_mix, row_out);

amp_frame = amp_frame(1:row_min,:);
mix_amp = abs(mix_fft(1:row_min,1:num_col_split));
IRM = (amp_frame.^2) ./ (mix_amp.^2);

mask_high_snr = IRM>IRM_gamma;
mask_mid_snr = IRM<=IRM_gamma & IRM>=IRM_eps;
mask_rest = ones(size(IRM)) - mask_high_snr - mask_mid_snr;

post_amp = mask_high_snr .* mix_amp + mask_mid_snr .* (mix_amp + amp_frame) / 2 + mask_rest.*amp_frame; 

dft_frame = zeros(num_frame, win_len);
wav_frame = zeros(num_frame, win_len);
%idx = 0:win_len-1;

for i=1:num_frame
    for j=1:num_col_split

        % idx = 1:win_len;
        %wav_frame(i,:) = wav_frame(i,:) + 2 * amp_frame(i,j) * cos((2*pi*(j-1)/win_len).*idx-phase_frame(i,j));
        
        % generate wav by IDFT instead of summing up cosine function
        %dft_frame(i,j) = amp_frame(i,j)*exp(1j*phase_frame(i,j));
        if isIdeal
        dft_frame(i,j) = amp_frame(i,j)*exp(1j*mix_phase(i,j));
        else
        dft_frame(i,j) = post_amp(i,j)*exp(1j*mix_phase(i,j));
		end        
    end
end

% construct whole frame
%dft_frame(:,num_col_split+1:win_len) = fliplr(dft_frame(:,1:num_col_split));

wav_frame = real(ifft(dft_frame')');

syn_wav = overlapadd(wav_frame, win_fun, win_shift);

syn_wav = syn_wav./max(abs(syn_wav));

end

